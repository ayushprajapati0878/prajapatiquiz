const quizData={
Easy:[
["GK","What is the capital of India?",["Mumbai","New Delhi","Kolkata","Chennai"],1],
["Science","Which planet is known as the Red Planet?",["Earth","Venus","Mars","Jupiter"],2],
["Math","What is 12 × 5?",["50","60","70","80"],1],
["Geography","Which is the largest ocean?",["Atlantic","Indian","Arctic","Pacific"],3],
["Sports","How many players are on a cricket team?",["9","10","11","12"],2],
["History","Who was known as the Iron Man of India?",["Sardar Vallabhbhai Patel","Subhas Chandra Bose","Bhagat Singh","Jawaharlal Nehru"],0],
["Science","What gas do humans need to breathe?",["Oxygen","Hydrogen","Helium","Carbon dioxide"],0],
["GK","How many days are there in a leap year?",["365","366","364","367"],1],
["Math","What is 100 ÷ 4?",["20","25","30","40"],1],
["Geography","Which country is famous for the pyramids of Giza?",["India","Egypt","Greece","Mexico"],1],
["Sports","Which sport uses a bat and ball?",["Swimming","Cricket","Boxing","Wrestling"],1],
["Science","Water freezes at what temperature in Celsius?",["0°C","10°C","50°C","100°C"],0],
["GK","How many colors are traditionally in a rainbow?",["5","6","7","8"],2],
["History","India became independent in which year?",["1945","1947","1950","1952"],1],
["Math","What is 9²?",["18","72","81","99"],2],
["Geography","Which continent is India in?",["Europe","Asia","Africa","Australia"],1],
["Sports","How many rings are on the Olympic flag?",["4","5","6","7"],1],
["Science","Which organ pumps blood?",["Lungs","Brain","Heart","Kidney"],2],
["GK","What is the national animal of India?",["Lion","Tiger","Elephant","Peacock"],1],
["Math","What is 15+25?",["30","35","40","45"],2]
],
Medium:[
["Science","What is the chemical symbol for gold?",["Ag","Au","Gd","Go"],1],
["History","Who founded the Maurya Empire?",["Ashoka","Chandragupta Maurya","Harsha","Samudragupta"],1],
["Math","What is the square root of 144?",["10","11","12","14"],2],
["Geography","Which is the longest river in India?",["Ganga","Yamuna","Godavari","Narmada"],0],
["Science","Which vitamin is mainly produced through sunlight exposure?",["Vitamin A","Vitamin B12","Vitamin C","Vitamin D"],3],
["GK","Which is the smallest prime number?",["0","1","2","3"],2],
["Sports","In which sport is the term 'love' used?",["Cricket","Tennis","Hockey","Golf"],1],
["History","Who wrote the Arthashastra?",["Kalidasa","Chanakya","Tulsidas","Banabhatta"],1],
["Math","What is 15% of 200?",["20","25","30","35"],2],
["Geography","Which Indian state has the longest coastline?",["Kerala","Tamil Nadu","Gujarat","Odisha"],2],
["Science","What is H2O?",["Oxygen","Hydrogen","Water","Salt"],2],
["GK","Which instrument measures atmospheric pressure?",["Thermometer","Barometer","Hygrometer","Altimeter"],1],
["Sports","How long is an Olympic swimming pool?",["25 m","40 m","50 m","100 m"],2],
["History","The Battle of Plassey was fought in which year?",["1757","1764","1857","1947"],0],
["Math","What is 7 × 8 + 4?",["56","60","64","68"],1],
["Geography","Which desert covers much of Rajasthan?",["Gobi","Sahara","Thar","Kalahari"],2],
["Science","Which blood cells help fight infections?",["Red blood cells","White blood cells","Platelets","Plasma"],1],
["GK","What is the currency of Japan?",["Won","Yuan","Yen","Ringgit"],2],
["Sports","Which country won the first Cricket World Cup in 1975?",["Australia","India","West Indies","England"],2],
["History","Who was the first Mughal emperor?",["Akbar","Babur","Humayun","Shah Jahan"],1]
],
Hard:[
["Science","What is the SI unit of electric resistance?",["Volt","Ohm","Ampere","Watt"],1],
["History","Who deciphered the Brahmi script?",["James Prinsep","Alexander Cunningham","William Jones","John Marshall"],0],
["Math","If x²=81 and x is positive, what is x?",["7","8","9","10"],2],
["Geography","Which strait separates India and Sri Lanka?",["Malacca Strait","Palk Strait","Bering Strait","Bosporus"],1],
["Science","Which particle has a negative electric charge?",["Proton","Neutron","Electron","Photon"],2],
["GK","Who wrote 'The Discovery of India'?",["Mahatma Gandhi","Jawaharlal Nehru","Rabindranath Tagore","A.P.J. Abdul Kalam"],1],
["Sports","In chess, which piece moves in an L shape?",["Bishop","Rook","Knight","Queen"],2],
["History","Which dynasty built most of the temples at Khajuraho?",["Chola","Chandela","Pallava","Gupta"],1],
["Math","What is the derivative of x²?",["x","2x","x²","2"],1],
["Geography","Which Indian river is known as the 'Sorrow of Bihar'?",["Kosi","Son","Narmada","Tapi"],0],
["Science","What is the approximate speed of light in vacuum?",["3×10^6 m/s","3×10^8 m/s","3×10^10 m/s","3×10^12 m/s"],1],
["GK","Which Article of the Indian Constitution deals with equality before law?",["Article 14","Article 19","Article 21","Article 32"],0],
["Sports","How many points is a touchdown worth in American football before the extra point?",["3","5","6","7"],2],
["History","Who was the last major ruler of the Vijayanagara Empire?",["Krishnadevaraya","Achyuta Deva Raya","Aliya Rama Raya","Harihara I"],2],
["Math","What is the probability of getting a head on a fair coin?",["1/4","1/3","1/2","2/3"],2],
["Science","Which gas is most abundant in Earth's atmosphere?",["Oxygen","Nitrogen","Carbon dioxide","Argon"],1],
["Geography","The Tropic of Cancer passes through how many Indian states?",["6","7","8","9"],2],
["GK","Which metal is liquid at room temperature?",["Iron","Mercury","Aluminium","Copper"],1],
["Sports","In badminton, what is the maximum score normally needed to win a game?",["15","21","25","30"],1],
["History","The Non-Cooperation Movement was launched in which year?",["1919","1920","1922","1930"],1]
],
Extreme:[
["Science","Which symmetry is associated with conservation laws via Noether's theorem?",["Gauge symmetry only","Continuous symmetry","Discrete symmetry only","Random symmetry"],1],
["Math","What is the determinant of [[1,2],[3,4]]?",["-2","2","10","-10"],0],
["Science","What is the ground-state electron configuration of carbon?",["1s²2s²2p²","1s²2s²2p⁴","1s²2s²2p⁶","1s²2p⁴"],0],
["History","Which treaty formally ended the First Anglo-Maratha War?",["Treaty of Salbai","Treaty of Bassein","Treaty of Purandar","Treaty of Surat"],0],
["Math","What is the integral of 1/x dx for x>0?",["x²/2","ln x + C","1/x² + C","e^x + C"],1],
["Science","Which principle states that no two identical fermions can occupy the same quantum state?",["Heisenberg principle","Pauli exclusion principle","Archimedes principle","Hubble law"],1],
["Geography","Which Indian state has the highest peak, Kanchenjunga, within its territory?",["Sikkim","Uttarakhand","Himachal Pradesh","Arunachal Pradesh"],0],
["GK","Which constitutional amendment added the words 'Socialist' and 'Secular' to the Preamble?",["24th","42nd","44th","73rd"],1],
["Math","What is the limit of sin(x)/x as x approaches 0?",["0","1","∞","Does not exist"],1],
["Science","Which law relates entropy to the number of microscopic configurations?",["Newton's law","Boltzmann relation","Ohm's law","Hooke's law"],1],
["History","Who was the first Indian Governor-General of independent India?",["C. Rajagopalachari","Rajendra Prasad","Sardar Patel","B. R. Ambedkar"],0],
["Math","If a matrix is 3×3, how many entries does it contain?",["6","9","12","27"],1],
["Science","What is the approximate Avogadro constant?",["6.022×10^23","9.81×10^23","3.00×10^8","1.602×10^-19"],0],
["Geography","Which ocean current is a major warm current affecting Western Europe?",["Labrador Current","Gulf Stream","Canary Current","Benguela Current"],1],
["GK","Which schedule of the Indian Constitution contains the anti-defection provisions?",["8th","9th","10th","11th"],2],
["Math","What is the eigenvalue equation for a matrix A?",["Av=λv","A+v=λ","A=λ+v","Av=v/λ"],0],
["Science","Which particle mediates the electromagnetic force in the Standard Model?",["Gluon","Photon","W boson","Higgs boson"],1],
["History","The Permanent Settlement was introduced by which Governor-General?",["Lord Wellesley","Lord Cornwallis","Lord Dalhousie","Lord Curzon"],1],
["Math","What is 2^10?",["512","1024","2048","4096"],1],
["Science","Which phenomenon demonstrates wave-particle duality for matter?",["Photoelectric effect","Electron diffraction","Blackbody radiation","Doppler effect"],1]
]};

let level="",questions=[],current=0,score=0,timer=20,interval=null,answered=false;
const $=id=>document.getElementById(id);
document.querySelectorAll(".level").forEach(b=>b.addEventListener("click",()=>startQuiz(b.dataset.level)));
$("nextBtn").addEventListener("click",()=>{current++;renderQuestion()});
$("restartBtn").addEventListener("click",()=>startQuiz(level));
$("homeBtn").addEventListener("click",()=>showHome());

function startQuiz(l){
  level=l; questions=[...quizData[l]]; current=0; score=0;
  $("home").classList.add("hidden"); $("result").classList.add("hidden"); $("quiz").classList.remove("hidden");
  renderQuestion();
}
function renderQuestion(){
  clearInterval(interval); answered=false;
  if(current>=questions.length){showResult();return}
  const q=questions[current];
  $("questionNo").textContent=`Question ${current+1} / ${questions.length}`;
  $("category").textContent=`${level} • ${q[0]}`;
  $("question").textContent=q[1];
  $("progressBar").style.width=`${(current/questions.length)*100}%`;
  $("answers").innerHTML="";
  q[2].forEach((text,i)=>{
    const btn=document.createElement("button");
    btn.className="answer"; btn.textContent=text;
    btn.onclick=()=>selectAnswer(i);
    $("answers").appendChild(btn);
  });
  $("nextBtn").classList.add("hidden");
  timer=20; $("timer").textContent=timer;
  interval=setInterval(()=>{timer--; $("timer").textContent=timer;if(timer<=0){clearInterval(interval);selectAnswer(-1)}},1000);
}
function selectAnswer(i){
  if(answered)return; answered=true; clearInterval(interval);
  const q=questions[current], buttons=[...document.querySelectorAll(".answer")];
  buttons.forEach((b,n)=>{b.disabled=true;if(n===q[3])b.classList.add("correct");if(n===i&&i!==q[3])b.classList.add("wrong")});
  if(i===q[3])score++;
  $("nextBtn").classList.remove("hidden");
}
function showResult(){
  clearInterval(interval); $("quiz").classList.add("hidden"); $("result").classList.remove("hidden");
  const pct=Math.round(score/questions.length*100);
  $("resultText").innerHTML=`You scored <strong>${score}/${questions.length}</strong> (${pct}%). Level: <strong>${level}</strong>.`;
}
function showHome(){
  clearInterval(interval); $("result").classList.add("hidden"); $("quiz").classList.add("hidden"); $("home").classList.remove("hidden");
}
