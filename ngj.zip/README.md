# Prajapati Quiz

Free static quiz game website.

## Files
- index.html — main quiz page
- style.css — responsive styling
- script.js — quiz logic and 80 questions
- sitemap.xml — search-engine sitemap
- robots.txt — crawler instructions
- favicon.svg — site icon

## GitHub Pages
1. Create a public GitHub repository named `quizmaster`.
2. Upload all files from this folder to the repository root.
3. Open Settings → Pages.
4. Select Deploy from a branch → `main` → `/ (root)` → Save.
5. Your free site will use a `github.io` address.

The canonical and sitemap URLs are prepared for `https://prajapatiquiz.com/`. If you use a different domain, change those URLs in `index.html`, `sitemap.xml`, and `robots.txt`.
